## Usage
Requires node.js and npm

```npm install```

```node problem.js --S <your S word here> --T <your T word here>
